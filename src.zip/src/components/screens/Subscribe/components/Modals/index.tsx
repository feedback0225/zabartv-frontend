// components
import SubscriptionModal from './components/SubscriptionModal'

const Modals = () => {
    return (
        <>
            <SubscriptionModal />
        </>
    )
}

export default Modals