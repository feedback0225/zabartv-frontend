export { Hero } from './components/Hero/Hero';
export { Category } from './components/Category/Category';
export { Music } from './components/Music/Music';
