export interface IPageInfo {
	currentPage: number;
	pageCount: number;
	perPage: number;
	totalCount: number;
}
