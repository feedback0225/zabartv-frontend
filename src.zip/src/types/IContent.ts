export interface IContent {
	mini_description: string;
	seo_description: string;
	seo_keywords: string;
	seo_title: string;
	slogan: string;
	text: string;
	theme: string;
	title: string;
	title_in_nav: string;
}
