export interface ICheckRating {
	film_id: number;
	film_rating: number;
}
