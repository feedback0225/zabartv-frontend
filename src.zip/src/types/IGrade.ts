export interface IGradeResponse {
	id: number | undefined;
	rating: number;
}
