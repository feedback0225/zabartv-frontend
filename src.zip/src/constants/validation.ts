export const requiredFieldMessage = 'Поле обязательно для заполнения';
export const incorrectlyFieldMessage = 'Поле заполнено некорректно';
export const requiredPasswordMessage = 'Введите пароль';
export const doNotMatchPasswordsMessage = 'Пароли не совпадают';
export const shortPasswordMessage = 'Пароль должен быть не менее 6 символов';
