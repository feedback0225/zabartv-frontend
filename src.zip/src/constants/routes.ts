export enum RoutesEnum {
	Home = '/',
	Films = '/films',
	Series = '/series',
	Cartoons = '/cartoons',
	Humor = '/humor',
	Music = '/music',
	Tv = '/tv',
	New = '/new',
	Cabinet = '/cabinet',
	Subscribe = '/subscribe',
	About = '/about',
	Policy = '/policy',
}
